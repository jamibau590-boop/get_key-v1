exports.handler = async (event, context) => {
    // Cuma terima POST request
    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
            },
            body: JSON.stringify({ success: false, message: 'Method not allowed' })
        };
    }

    try {
        // Parse body
        const body = JSON.parse(event.body);
        const { app_id, session_id } = body;

        // Validasi sederhana
        if (!app_id || !session_id) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                },
                body: JSON.stringify({ success: false, message: 'Missing parameters' })
            };
        }

        // Generate key random (format: M11-XXXXXX-XXXXXX-XXXXXX)
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let key = 'M11-';
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 6; j++) {
                key += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            if (i < 2) key += '-';
        }

        // Tambahin timestamp (1 hari expired)
        const createdAt = new Date().toISOString();
        const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 5000).toISOString();

        // Simpan ke Netlify Blob (storage gratis) — OPTIONAL
        // Kalau mau simpan history key, aktifin ini:
        /*
        const { getStore } = require('@netlify/blobs');
        const store = getStore('keys');
        await store.set(key, JSON.stringify({
            app_id,
            session_id,
            createdAt,
            expiresAt,
            used: false
        }));
        */

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
            },
            body: JSON.stringify({
                success: true,
                license_key: key,
                created_at: createdAt,
                expires_at: expiresAt
            })
        };

    } catch (error) {
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
            },
            body: JSON.stringify({ success: false, message: 'Server error: ' + error.message })
        };
    }
};
